<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Collection;
use App\Models\Cluster;

class ClusterMembersExport implements FromCollection, WithHeadings
{
    protected $cluster;

    public function __construct(Cluster $cluster)
    {
        $this->cluster = $cluster;
    }

    public function collection()
    {
        $rows = collect();
        // Export simple, reliable fields that exist on ClusterMember / related Customer
        $members = $this->cluster->clusterMembers()->with('customer')->get();

        foreach ($members as $m) {
            $rows->push([
                'Customer ID' => $m->customer_id,
                'Cluster' => $m->cluster_number ?? '',
                'Frequency' => $m->frequency,
                'Total Spent' => $m->total_spent,
                // keep name for convenience
                'Customer Name' => optional($m->customer)->name ?? ''
            ]);
        }
        return $rows;
    }

    public function headings(): array
    {
        return [
            'Customer ID',
            'Cluster',
            'Frequency',
            'Total Spent',
            'Customer Name'
        ];
    }
}
