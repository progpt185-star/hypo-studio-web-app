<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ config('hypo.app_name') }}</title>
</head>
<body>
    <h1>{{ config('hypo.app_name') }}</h1>
    <p>If you see this page, the view system is working.</p>
</body>
</html>
